# function = a lock of code which is executed only when it is called.

def hello(name,name2,age):
    print("Hello "+name)
    print("Hello again "+name2)
    print("Hello once again "+name+" and "+name2)
    print("You are "+str(age)+" years old")
    print("Have a nice day!")


hello("Man","Bro", 21)
