def hello():
    print("Hello! Have a Nice Day!")
def bye():
    print("Goodbye! Safe Travels!")