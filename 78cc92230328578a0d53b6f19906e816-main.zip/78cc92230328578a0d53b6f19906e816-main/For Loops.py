import time
# For loop = a statement that will execute it's block of code
#            a limited amount of times
#            while loop = unlimited
#            for loop = limited

#for i in range(10):
    #time.sleep(1)
    #print(i + 1)

#for i in "Sanjaynarayan Dhamodharan":
    #print(i)

#for seconds in range(10,-1,-1):
    #time.sleep(1)
    #print(seconds)
    #if seconds == (0):
        #time.sleep(1)
        #print("Happy Birthday!")

#for i in range(10):
    #print(i+1)
#for i in range (50,101,2):
    #print(i)

#for i in "Sanjaynarayan Dhamodharan":
    #print(i)

#for seconds in range(10,0,-1):
    #print(seconds)
    #time.sleep(1)
#print("Happy New Year!")

#x = ("Hello, Hi, Whats up?")

#for i in x:
    #print(i)
#for i in range(10):
    #print(i+1)

#for i in range (50,101,3):
    #print(i)
#for i in "Sanjaynarayan Dhamodharan":
    #print(i)

#for seconds in range (10,0,-1):
    #print(seconds)
    #time.sleep(1)
#print("Happy New Year!")