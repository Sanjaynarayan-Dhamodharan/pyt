#String Class
first_name="Jonathan"
last_name="Joestar"
full_name=first_name +" "+ last_name
print(full_name)
#print(type(name))
#print("Sheesh "+name)




#Integer Class
age = 21
age += 1
print(age)
print(type(age))
#print("your age is"+age) wont work since 2 diff classes
print("your age is " +str(age))

#Float Class
height = 250.2783232
print(height)
print(type(height))

print("hello Mister xyz, You are: " + str(height) + " Years old")



#Float Class
#height = 250.5
#print(height)
#print(type(height))
#print("Your height is " + str(height)+"cm")




#Boolean Class
#human = False
#print(human)
#print(type(human))
#print("Are you a human: " +str(human))