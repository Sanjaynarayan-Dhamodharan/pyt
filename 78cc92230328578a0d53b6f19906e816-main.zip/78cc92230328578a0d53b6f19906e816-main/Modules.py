# module = a file containing python code. May contain functions, classes, etc.
# used with modular programming, whihc is to seperate a program into parts

#import Messages as msg

#msg.hello()
#msg.bye()

# OR

#from Messages import hello,bye
#hello()
#bye()

help("modules")