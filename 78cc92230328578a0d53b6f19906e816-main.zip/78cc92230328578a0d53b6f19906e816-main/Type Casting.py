#Type Casting = convert the data tupe of a value to anotehr data type.

x = 1 #int
y = 2.0 #float
z="3" #str

#x = str(x)
#y = int(y)
#z = float(z)

print("X is "+str(x))
print("X is "+str(y))
print(z*3)

