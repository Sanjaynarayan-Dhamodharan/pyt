name = input("What is your name?: ")
print(name)

age = input("How old are you?: ")
print(str(age))