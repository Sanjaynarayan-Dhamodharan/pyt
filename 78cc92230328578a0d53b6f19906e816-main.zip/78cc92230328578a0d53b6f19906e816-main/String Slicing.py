# slicing = create a substring by extracting elements from another string
#              Indexing[] or Slice()
#              [start:stop:step]

#name = "Chu Papi"

#first_name = name[0:3]
#last_name = name[3:8]
#chunky = name[0:8:3]
#reversed_name = name[::-1]
#print(reversed_name)
#print(chunky)
#print(first_name+last_name)

website = "https://google.com"
website_2 = "https://lenovo.com"

slice = slice(8,-4)

print(website_2[slice])
print(website[slice])
