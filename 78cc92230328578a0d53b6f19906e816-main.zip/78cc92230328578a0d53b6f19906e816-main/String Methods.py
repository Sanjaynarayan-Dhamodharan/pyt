name="Bro code"

print(len(name))
print(name.upper())
print(name.lower())
print(name.capitalize())

#print(len(name))
#len finds the amount of characters or length of the string

#print(name.find("C"))
#Finds first character withing string. Starts from 0.

#print(name.capitalize())
#Capitalizes the string

#print(name.upper())
#Makes everything in string uppercase

#print(name.lower())
#Makes everything in string lowercase

#print(name.isdigit())
#Says true or false whether the string is a digit

#print(name.isalpha())
#Check to see if string contains only letters (excluding spaces)

#print(name.count("o"))
#States how many of the character is in the string

#print(name.replace("o","a"))
#Replaces all of the character in string into different character

#print(name*5)
#shows string multiple times