# 2D lists = a list of lists

drink = ["coke", "pepsi", "sprite"]
dinner = ["pizza", "hamburger", "hotdog"]
dessert = ["ice cream", "cake"]

food = [drink, dinner, dessert]

print(food[1][1])
