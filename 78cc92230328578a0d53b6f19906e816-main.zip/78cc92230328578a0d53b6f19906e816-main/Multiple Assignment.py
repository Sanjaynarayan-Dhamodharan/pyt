# Multiple assignment = allows us to assign multiple variables at the same time in one line of code

#name = "Bro"
#age = 21
#attractive = True


#name, age, attractive = "Bro", 21, True Faster Way to do the thing above
name, age, attractive = "Bro", 21, True
print(name,age,attractive)
print("Hello " + name + " are you " + str(age) + " years old? And you are attractive? Yes, because you being attractive is " + str(attractive) + "!")

#print(name)
#print(age)
#print(attractive)


#print(name + " " + str(age) + " " + str(attractive)) Way to print out all 3 of them in one line


#Spongebob, Patrick, Sandy, Squidward = 30 
#Used for integers
