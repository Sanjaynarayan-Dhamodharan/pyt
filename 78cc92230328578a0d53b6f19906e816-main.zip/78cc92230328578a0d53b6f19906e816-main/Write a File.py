text = "Have a nice day! See ya"

with open('test.txt','a') as file:
    file.write(text)